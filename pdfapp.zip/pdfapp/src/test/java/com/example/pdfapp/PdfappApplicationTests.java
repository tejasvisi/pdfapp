package com.example.pdfapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdfappApplicationTests {

	@Test
	void contextLoads() {
	}

}
